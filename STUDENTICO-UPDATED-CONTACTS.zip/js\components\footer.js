import { brand, navLinks, skills, socials, contact } from "../data/content.js";
import { escapeHtml, mapHtml, icon } from "../utils/helpers.js";

export const footer = {
  mount: "#site-footer",

  render() {
    const year = new Date().getFullYear();
    return `
      <div class="container">
        <div class="footer__top">
          <div class="footer__brand">
            <img src="assets/logo/studentico-logo-light.svg" alt="Studentico" width="850" height="256">
            <p>Affordable essentials, practical skills, and meaningful opportunities.</p>
            <div class="footer__socials">
              ${mapHtml(socials, (s) => `<a href="${s.href}" aria-label="${escapeHtml(s.label)}">${icon(s.path, { size: 20 })}</a>`)}
            </div>
          </div>

          <nav class="footer__col" aria-label="Footer navigation">
            <h4>EXPLORE</h4>
            <ul>${mapHtml(navLinks, (l) => `<li><a href="${l.href}">${escapeHtml(l.label)}</a></li>`)}</ul>
          </nav>

          <nav class="footer__col" aria-label="Skills">
            <h4>OUR SKILLS</h4>
            <ul>${mapHtml(skills, (s) => `<li><a href="#skills">${escapeHtml(s.name)}</a></li>`)}</ul>
          </nav>

          <div class="footer__col footer__col--contact">
            <h4>GET IN TOUCH</h4>
            <ul class="footer__contact">
              <li><b>Email</b><a href="mailto:${escapeHtml(contact.email)}">${escapeHtml(contact.email)}</a></li>
              <li><b>Phone</b><a href="tel:${escapeHtml(contact.phone)}">${escapeHtml(contact.phone)}</a></li>
              <li><b>Skills WhatsApp</b><a href="https://wa.me/2347067409576?text=Hello%20Studentico%2C%20I%20would%20like%20to%20enquire%20about%20the%20Skills%20Acquisition%20and%20Empowerment%20Programme%201.0." target="_blank" rel="noopener">${escapeHtml(contact.skillsWhatsApp)}</a></li>
              <li><b>Location</b>${escapeHtml(contact.location)}</li>
            </ul>
          </div>
        </div>
      </div>

      <div class="footer__wordmark" aria-hidden="true">Studentico</div>

      <div class="container">
        <div class="footer__bottom">
          <span>© ${year} Studentico. All rights reserved.</span>
          <span>${escapeHtml(brand.programme)}</span>
        </div>
      </div>`;
  },
};
